__author__ = 'cyrbuzz'

from singsFrameBase import SingsFrameBase, SingsSearchResultFrameBase


class QQSingsArea(SingsFrameBase):

    def __init__(self, parent=None):
        super(QQSingsArea, self).__init__(parent)


class QQSearchResultFrame(SingsSearchResultFrameBase):

    def __init__(self, parent=None):
        super(QQSearchResultFrame, self).__init__(parent)