__author__ = 'cyrbuzz'

from singsFrameBase import SingsFrameBase, SingsSearchResultFrameBase


class XiamiSingsArea(SingsFrameBase):

    def __init__(self, parent=None):
        super(XiamiSingsArea, self).__init__(parent)


class XiamiSearchResultFrame(SingsSearchResultFrameBase):

    def __init__(self, parent=None):
        super(XiamiSearchResultFrame, self).__init__(parent)
        