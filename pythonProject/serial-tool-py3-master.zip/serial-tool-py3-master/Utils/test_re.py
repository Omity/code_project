import re
import sys

#sss="abc def s5sd klwer1 43209r09143513r 98qef329 8r8woi fsof32 4por"
sss="883e aadd 33 44 55 66 ff dd ee 22 dd ff 66 77 88 9999992342 1221 abcd ed ef FF EEAADDBB"
pattern = re.compile(r'[^ 0-9a-fA-F]+')
result = pattern.findall(sss)
if result:
    print(result)  #返回
else:
    print("not find!!!")